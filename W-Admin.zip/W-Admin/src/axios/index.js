import axios from 'axios'
let http = axios.create({
  baseURL: 'http://172.16.0.113:9235/',
  timeout: 10000,
  withCredentials: true, //跨域
  headers: {
    'Content-Type': 'application/json;charset=utf-8',
  },
});
function apiAxios(method, url, params, response) {
  typeof params == 'function'? response=params: params
  http({
    method: method,
    url: url,
    data: method === 'POST' || method === 'PUT' ? params : null,
    params: method === 'GET' || method === 'DELETE' ? params : null,
  }).then(function (res) {
	switch (res.data.code)
		{
			case 200 :{      
				response(res.data);
				break;
			}
			case 203 :{        //登录过期
				alert('登录过期，请重新登录')
				window.local.href='/login'
				break;
			}
			case 400 :{        
				console.error(url+'用户请求错误，请检查发送的参数')
				break;
			}
			case 404 :{        
				console.error(url+'请求接口不存在')
				break;
			}
			case 500 :{        
				console.error(url+'服务器发生错误，code:500')
				break;
			}
			default:
				alert('服务器存在异常')
				console.error('服务器存在异常', 'middle')
				break;
		}
  }).catch(function (err) {
    response(err);
  })
}

export default {
  get: function (url, params, response) {
    return apiAxios('GET', url, params, response)
  },
  post: function (url, params, response) {
    return apiAxios('POST', url, params, response)
  },
  put: function (url, params, response) {
    return apiAxios('PUT', url, params, response)
  },
  delete: function (url, params, response) {
    return apiAxios('DELETE', url, params, response)
  }
}
