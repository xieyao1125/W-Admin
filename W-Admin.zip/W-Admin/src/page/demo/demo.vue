<template>
  <div class="menuListBox">
    <h1>金融项目通用框架</h1>
  </div>
</template>

<script>
  export default {
    name:"menuListBox",
    data(){
      return {
        
      }
    },
	created() {
        
	}
  }
</script>

<style>
</style>
