<template>
  <div class="menuListBox">
    
  </div>
</template>

<script>
  export default {
    name:"menuListBox",
    data(){
      return {
        
      }
    }
  }
</script>

<style>
</style>
