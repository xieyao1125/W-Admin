<template>
  <div id="app">
	<el-container>
		<el-header class="headerBack">W - Admin金融项目通用框架</el-header>
		<el-container>
			<el-aside width="201px">
				<myMenu></myMenu>
			</el-aside>
			<el-main>
				<router-view ></router-view>
			</el-main>
		</el-container>
	</el-container>
  </div>
</template>

<script>
import menu from './components/menu.vue'
export default {
  name: 'App',
  components:{
    myMenu:menu,
  }
}
</script>

<style>
#app {
  font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
.headerBack{background-color: #409EFF;text-align: left;font-size: 22px;line-height: 60px;color: #fff;font-weight: 400;}
body{
	margin: 0;
}
</style>
