<template>
  <div class="menuListBox">
	<el-menu
		default-active="1-1"
		class="el-menu-vertical-demo"
		background-color="#545c64"
		:unique-opened="true"
		:router="true"
		menu-trigger="hover"
		text-color="#fff"
		active-text-color="#ffd04b">
		<div v-for="(item,index) in menuList" :key="'menu'+index" >
			<el-submenu :index="item.index" v-if="item.children">
				<template slot="title">
					<i class="el-icon-location"></i>
					<span>{{item.name}}</span>
				</template>
				<el-menu-item-group >
					<el-menu-item v-for="(item1,index) in item.children" :index="item1.index" :key="'item1'+index">{{item1.name}}</el-menu-item>
				</el-menu-item-group>
			</el-submenu>
			<el-menu-item v-else :index="item.index">
				<i class="el-icon-menu"></i>
				<span slot="title">{{item.name}}</span>
			</el-menu-item>
		</div>
	</el-menu>
  </div>
</template>

<script>
  export default {
    name:"menuListBox",
    data(){
      return {
        menuList:[
			{name:"Echarts",children:[{name:'柱状图',index:'1-1'}],index:'1'},
			{name:"组件库",index:'2'}
		],
		selectedOptins:[]
      }
    },
	created() {
    }
  }
</script>

<style>
</style>
