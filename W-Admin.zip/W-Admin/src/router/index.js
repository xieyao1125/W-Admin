import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const route = new Router({
  routes:[
    {
        path: '/demo/demo',
        name: 'demo-demo',
        component:()=> import('@/page/demo/demo.vue')
    },
	{
        path: '/',
        name: '/',
        component:()=> import('@/page/demo/demo.vue')
	},
	{
        path: '/echarts/index',
        name: 'echarts-index',
        component:()=> import('@/page/echarts/index.vue')
	},
  ]
})

export default route